//
//  workouttest.swift
//  InTheZone
//
//  Created by Alex Brankin on 14/04/2024.
//

import SwiftUI
import Foundation

struct workouttest: View {
    let names = ["Holly", "Josh", "Rhonda", "Ted"]
    @State private var searchText = ""
    
    /// A site name filter phrase entered by the user.
    @State private var query: String = ""
    
    var body: some View {
        VStack {
            NavigationView {
                VStack {
                    List {
                        ForEach(searchResults, id: \.self) { name in
                            Text(name)
                        }
                    }
                }
                .searchable(
                    text: $query,
                    placement: .navigationBarDrawer(displayMode: .always),
                    prompt: "Search"
                )
                .navigationTitle("Workouts")
                .background(Color.gray)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.gray)
    }
    
    var searchResults: [String] {
        if searchText.isEmpty {
            return names
        } else {
            return names.filter { $0.contains(searchText) }
        }
    }
}

struct workouttest_Previews: PreviewProvider {
    static var previews: some View {
        workouttest()
    }
}
