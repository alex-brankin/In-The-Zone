//
//  YourWorkoutsView.swift
//  InTheZone
//
//  Created by Alex Brankin on 14/04/2024.
//

//
//  YourHeartView.swift
//  InTheZone
//
//  Created by Alex Brankin on 03/04/2024.
//

import SwiftUI

struct YourWorkoutsView: View {
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
               WorkoutsView()
            }
            .padding() // Add some padding for better spacing
            
        }
        
    }
}

struct YourWorkouts: PreviewProvider {
    static var previews: some View {
        YourWorkoutsView()
    }
}

